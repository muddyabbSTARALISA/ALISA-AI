class MemoryManager:
    """Первая версия памяти: пользователь сам решает, что Алисе запомнить."""
    def __init__(self, database):
        self.database = database

    def add(self, content: str):
        content = content.strip()
        if content:
            self.database.add_memory(content)

    def all(self):
        return self.database.get_memories()

    def delete(self, memory_id: int):
        self.database.delete_memory(memory_id)

    def build_context(self) -> str:
        items = self.all()
        if not items:
            return "Пока нет сохранённых воспоминаний."
        return "\n".join(f"- {item['content']}" for item in items)
