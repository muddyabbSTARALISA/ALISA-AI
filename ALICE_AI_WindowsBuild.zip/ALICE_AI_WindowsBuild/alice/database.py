from __future__ import annotations
import sqlite3
from pathlib import Path
from datetime import datetime, timezone

def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat()

class Database:
    def __init__(self, path: Path):
        path.parent.mkdir(parents=True, exist_ok=True)
        self.connection = sqlite3.connect(str(path))
        self.connection.row_factory = sqlite3.Row
        self.connection.execute("PRAGMA journal_mode=WAL")
        self.connection.execute("PRAGMA foreign_keys=ON")
        self._create_tables()

    def _create_tables(self):
        with self.connection:
            self.connection.execute("""
                CREATE TABLE IF NOT EXISTS messages (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    role TEXT NOT NULL CHECK(role IN ('user','assistant')),
                    content TEXT NOT NULL,
                    created_at TEXT NOT NULL
                )
            """)
            self.connection.execute("""
                CREATE TABLE IF NOT EXISTS memories (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    content TEXT NOT NULL,
                    created_at TEXT NOT NULL
                )
            """)

    def add_message(self, role: str, content: str):
        with self.connection:
            self.connection.execute(
                "INSERT INTO messages(role, content, created_at) VALUES(?,?,?)",
                (role, content, utc_now())
            )

    def get_recent_messages(self, limit: int = 30) -> list[dict]:
        rows = self.connection.execute(
            "SELECT role, content FROM messages ORDER BY id DESC LIMIT ?", (limit,)
        ).fetchall()
        return [dict(row) for row in reversed(rows)]

    def get_all_messages(self) -> list[dict]:
        rows = self.connection.execute(
            "SELECT role, content, created_at FROM messages ORDER BY id"
        ).fetchall()
        return [dict(row) for row in rows]

    def clear_history(self):
        with self.connection:
            self.connection.execute("DELETE FROM messages")

    def add_memory(self, content: str):
        with self.connection:
            self.connection.execute(
                "INSERT INTO memories(content, created_at) VALUES(?,?)", (content, utc_now())
            )

    def get_memories(self) -> list[dict]:
        rows = self.connection.execute(
            "SELECT id, content, created_at FROM memories ORDER BY id DESC"
        ).fetchall()
        return [dict(row) for row in rows]

    def delete_memory(self, memory_id: int):
        with self.connection:
            self.connection.execute("DELETE FROM memories WHERE id=?", (memory_id,))

    def close(self):
        self.connection.close()
