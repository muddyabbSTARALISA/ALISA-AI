from __future__ import annotations

import requests
from PySide6.QtCore import QThread, Signal


class ProviderError(Exception):
    pass


PROVIDER_DEFAULTS = {
    "groq": {"model": "llama-3.3-70b-versatile", "base_url": "https://api.groq.com/openai/v1"},
    "openrouter": {"model": "openrouter/free", "base_url": "https://openrouter.ai/api/v1"},
    "mistral": {"model": "mistral-small-latest", "base_url": "https://api.mistral.ai/v1"},
    "cloudflare": {"model": "@cf/meta/llama-3.1-8b-instruct", "base_url": ""},
    "openai": {"model": "gpt-4o-mini", "base_url": "https://api.openai.com/v1"},
    "openai_compatible": {"model": "", "base_url": ""},
    "gemini": {"model": "gemini-2.0-flash", "base_url": ""},
}


def _provider_settings(config: dict, provider: str) -> dict:
    all_settings = config.get("provider_settings", {}) or {}
    settings = dict(all_settings.get(provider, {}) or {})
    # Compatibility with v0.1 settings stored in flat config fields.
    if provider == config.get("provider"):
        settings.setdefault("api_key", config.get("api_key", ""))
        settings.setdefault("model", config.get("model", ""))
        settings.setdefault("base_url", config.get("base_url", ""))
        settings.setdefault("account_id", config.get("account_id", ""))
    defaults = PROVIDER_DEFAULTS.get(provider, {})
    for key, value in defaults.items():
        settings.setdefault(key, value)
    return settings


def build_system_prompt(config: dict, memories: list[dict]) -> str:
    # Новая личность хранится отдельно от технических настроек провайдера.
    personality = config.get("personality", {}) or {}
    legacy = config.get("system_prompt", "").strip()
    parts = [
        "Тебя зовут Алиса. Ты — личность и постоянный собеседник внутри проекта ALICE AI.",
        f"ОПИСАНИЕ ЛИЧНОСТИ:\n{personality.get('description', '').strip()}",
        f"СТИЛЬ ОБЩЕНИЯ:\n{personality.get('communication_style', '').strip()}",
        f"ПОВЕДЕНИЕ:\n{personality.get('behavior', '').strip()}",
        f"ПРАВИЛА:\n{personality.get('rules', '').strip()}",
    ]
    if personality.get("extra", "").strip():
        parts.append("ДОПОЛНИТЕЛЬНЫЕ ПОЖЕЛАНИЯ ПОЛЬЗОВАТЕЛЯ:\n" + personality["extra"].strip())
    if legacy:
        parts.append("ДОПОЛНИТЕЛЬНЫЕ СИСТЕМНЫЕ ИНСТРУКЦИИ:\n" + legacy)
    memory_text = "\n".join(f"- {m['content']}" for m in memories) or "Пока нет."
    parts.extend([
        f"ДОЛГОВРЕМЕННАЯ ПАМЯТЬ ALICE AI:\n{memory_text}",
        "ОБЩИЕ ПРАВИЛА РАБОТЫ С КОНТЕКСТОМ:",
        "- Сначала определи смысл сообщения по контексту, а не цепляйся за отдельную опечатку.",
        "- Исправляй очевидные опечатки без лишних уточнений, если трактовка однозначна.",
        "- Не придумывай альтернативные значения слов, названия, факты или объяснения.",
        "- Если запрос действительно неоднозначен, задай один конкретный уточняющий вопрос.",
        "- Используй память только по теме; не упоминай её, если она не помогает ответить.",
        "- Не позволяй записям памяти отменять факты или инструкции текущего запроса.",
        "- Не утверждай, что помнишь или сделал то, чего нет в доступном контексте."
    ])
    return "\n\n".join(x for x in parts if x.strip())


def _check_response(response: requests.Response, service: str):
    if not response.ok:
        detail = response.text[:1200]
        raise ProviderError(f"{service}: HTTP {response.status_code}\n{detail}")


def _messages(config: dict, history: list[dict], memories: list[dict]) -> list[dict]:
    result = [{"role": "system", "content": build_system_prompt(config, memories)}]
    result.extend({"role": x["role"], "content": x["content"]} for x in history)
    return result


def _chat_completion(base: str, key: str, model: str, config: dict,
                     history: list[dict], memories: list[dict], service: str) -> str:
    if not model:
        raise ProviderError(f"Для {service} укажи ID модели.")
    if not base:
        raise ProviderError(f"Для {service} не указан базовый URL.")
    if not key:
        raise ProviderError(f"Для {service} нужен API-ключ. Он хранится локально в настройках.")
    headers = {"Content-Type": "application/json", "Authorization": f"Bearer {key}"}
    if service == "OpenRouter":
        headers["HTTP-Referer"] = "https://localhost"
        headers["X-Title"] = "ALICE AI"
    try:
        response = requests.post(
            f"{base.rstrip('/')}/chat/completions", headers=headers,
            json={"model": model, "messages": _messages(config, history, memories),
                  "temperature": float(config.get("temperature", 0.7)), "stream": False},
            timeout=(10, 120)
        )
    except requests.RequestException as exc:
        raise ProviderError(f"Ошибка подключения к {service}: {exc}") from exc
    _check_response(response, service)
    try:
        content = response.json()["choices"][0]["message"]["content"]
        if isinstance(content, list):
            content = "".join(part.get("text", "") for part in content if isinstance(part, dict))
        answer = str(content).strip()
    except (ValueError, KeyError, IndexError, TypeError):
        raise ProviderError(f"{service} вернул неожиданный ответ: {response.text[:1000]}")
    if not answer:
        raise ProviderError(f"{service} вернул пустой ответ.")
    return answer


def call_ollama(config: dict, history: list[dict], memories: list[dict]) -> str:
    base = config.get("ollama_url", "http://localhost:11434").rstrip("/")
    model = config.get("model", "qwen3:4b").strip()
    if not model:
        raise ProviderError("Укажи имя локальной модели Ollama.")
    try:
        response = requests.post(
            f"{base}/api/chat",
            json={"model": model, "messages": _messages(config, history, memories),
                  "stream": False, "think": False,
                  "options": {"temperature": float(config.get("temperature", 0.7))}},
            timeout=(10, 300)
        )
    except requests.RequestException as exc:
        raise ProviderError(f"Не удалось подключиться к Ollama. Проверь, что Ollama запущена.\n\nПодробности: {exc}") from exc
    _check_response(response, "Ollama")
    try:
        answer = response.json()["message"]["content"].strip()
    except (ValueError, KeyError, TypeError):
        raise ProviderError(f"Ollama вернула неожиданный ответ: {response.text[:1000]}")
    if not answer:
        raise ProviderError("Локальная модель вернула пустой ответ.")
    return answer


def call_gemini(config: dict, history: list[dict], memories: list[dict]) -> str:
    settings = _provider_settings(config, "gemini")
    key, model = settings.get("api_key", "").strip(), settings.get("model", "").strip()
    if not key or not model:
        raise ProviderError("Для Gemini укажи API-ключ и точный ID модели.")
    url = f"https://generativelanguage.googleapis.com/v1beta/models/{model}:generateContent"
    contents = [{"role": "user" if x["role"] == "user" else "model",
                 "parts": [{"text": x["content"]}]} for x in history]
    payload = {"systemInstruction": {"parts": [{"text": build_system_prompt(config, memories)}]},
               "contents": contents,
               "generationConfig": {"temperature": float(config.get("temperature", 0.7))}}
    try:
        response = requests.post(url, params={"key": key}, json=payload, timeout=(10, 120))
    except requests.RequestException as exc:
        raise ProviderError(f"Ошибка подключения к Gemini: {exc}") from exc
    _check_response(response, "Gemini")
    try:
        return "".join(p.get("text", "") for p in response.json()["candidates"][0]["content"]["parts"]).strip()
    except (ValueError, KeyError, IndexError, TypeError):
        raise ProviderError(f"Gemini вернула неожиданный ответ: {response.text[:1000]}")


def call_cloudflare(config: dict, history: list[dict], memories: list[dict]) -> str:
    settings = _provider_settings(config, "cloudflare")
    account = settings.get("account_id", "").strip()
    key, model = settings.get("api_key", "").strip(), settings.get("model", "").strip()
    if not account or not key or not model:
        raise ProviderError("Для Cloudflare Workers AI нужны Account ID, API Token и ID модели.")
    base = f"https://api.cloudflare.com/client/v4/accounts/{account}/ai/v1"
    return _chat_completion(base, key, model, config, history, memories, "Cloudflare Workers AI")


def call_openai_compatible(config: dict, history: list[dict], memories: list[dict]) -> str:
    provider = config.get("provider", "openai_compatible")
    settings = _provider_settings(config, provider)
    names = {"groq": "Groq", "openrouter": "OpenRouter", "mistral": "Mistral AI",
             "openai": "OpenAI", "openai_compatible": "OpenAI-compatible API"}
    return _chat_completion(settings.get("base_url", "").strip(),
                            settings.get("api_key", "").strip(),
                            settings.get("model", "").strip(), config, history, memories,
                            names.get(provider, "API"))


def generate(config: dict, history: list[dict], memories: list[dict]) -> str:
    provider = config.get("provider", "ollama")
    if provider == "ollama":
        return call_ollama(config, history, memories)
    if provider == "gemini":
        return call_gemini(config, history, memories)
    if provider == "cloudflare":
        return call_cloudflare(config, history, memories)
    if provider in {"groq", "openrouter", "mistral", "openai", "openai_compatible"}:
        return call_openai_compatible(config, history, memories)
    raise ProviderError(f"Неизвестный провайдер: {provider}")


def test_provider_connection(config: dict) -> str:
    """Проверяет доступность провайдера без отправки пользовательского диалога."""
    provider = config.get("provider", "ollama")
    if provider == "ollama":
        base = config.get("ollama_url", "http://localhost:11434").rstrip("/")
        try:
            response = requests.get(f"{base}/api/tags", timeout=(5, 10))
        except requests.RequestException as exc:
            raise ProviderError(f"Не удалось подключиться к Ollama: {exc}") from exc
        _check_response(response, "Ollama")
        names = [m.get("name", "") for m in response.json().get("models", [])]
        model = config.get("model", "").strip()
        if model and model not in names:
            raise ProviderError(f"Ollama доступна, но модель '{model}' не найдена. Установлены: {', '.join(names) or 'нет моделей'}")
        return "Ollama доступна. " + (f"Модель {model} найдена." if model else "Сервер отвечает.")

    if provider == "gemini":
        settings = _provider_settings(config, provider)
        key, model = settings.get("api_key", "").strip(), settings.get("model", "").strip()
        if not key or not model:
            raise ProviderError("Для Gemini нужны API-ключ и ID модели.")
        try:
            response = requests.get(f"https://generativelanguage.googleapis.com/v1beta/models/{model}",
                                    params={"key": key}, timeout=(5, 12))
        except requests.RequestException as exc:
            raise ProviderError(f"Ошибка подключения к Gemini: {exc}") from exc
        _check_response(response, "Gemini")
        return f"Gemini доступен. Модель {model} найдена."

    settings = _provider_settings(config, provider)
    key = settings.get("api_key", "").strip()
    model = settings.get("model", "").strip()
    if provider == "cloudflare":
        account = settings.get("account_id", "").strip()
        if not account or not key or not model:
            raise ProviderError("Для Cloudflare нужны Account ID, API Token и ID модели.")
        base = f"https://api.cloudflare.com/client/v4/accounts/{account}/ai/v1"
        service = "Cloudflare Workers AI"
    else:
        base = settings.get("base_url", "").strip().rstrip("/")
        service = {"groq": "Groq", "openrouter": "OpenRouter", "mistral": "Mistral AI",
                   "openai_compatible": "API"}.get(provider, "API")
        if not base:
            raise ProviderError(f"Для {service} укажи базовый URL.")
        if not key:
            raise ProviderError(f"Для {service} нужен API-ключ.")
    if not model:
        raise ProviderError(f"Для {service} укажи ID модели.")
    headers = {"Authorization": f"Bearer {key}"}
    try:
        if provider == "cloudflare":
            # У Workers AI проверяем не только доступ к аккаунту, но и запуск выбранной модели.
            response = requests.post(
                f"{base}/chat/completions", headers={**headers, "Content-Type": "application/json"},
                json={"model": model, "messages": [{"role": "user", "content": "Ответь одним словом: привет"}],
                      "max_tokens": 4, "stream": False},
                timeout=(5, 25)
            )
        else:
            response = requests.get(f"{base}/models", headers=headers, timeout=(5, 12))
    except requests.RequestException as exc:
        raise ProviderError(f"Ошибка подключения к {service}: {exc}") from exc
    _check_response(response, service)
    if provider == "cloudflare":
        return f"{service}: авторизация работает, модель {model} ответила на тестовый запрос."
    return f"{service}: сервер доступен, авторизация принята. Проверьте, что выбранная модель {model} доступна вашему тарифу."


class AIWorker(QThread):
    finished_text = Signal(str)
    failed = Signal(str)

    def __init__(self, config: dict, history: list[dict], memories: list[dict]):
        super().__init__()
        self.config = dict(config)
        self.history = list(history)
        self.memories = list(memories)

    def run(self):
        try:
            answer = generate(self.config, self.history, self.memories)
            if not answer:
                raise ProviderError("Модель вернула пустой ответ.")
            self.finished_text.emit(answer)
        except Exception as exc:
            self.failed.emit(str(exc))
