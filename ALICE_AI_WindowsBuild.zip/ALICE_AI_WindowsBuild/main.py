from __future__ import annotations
import sys
import os
from pathlib import Path

from PySide6.QtCore import Qt, QEvent, QTimer, QPropertyAnimation, QEasingCurve
from PySide6.QtWidgets import (
    QApplication, QMainWindow, QWidget, QVBoxLayout, QHBoxLayout,
    QTextBrowser, QTextEdit, QPushButton, QLabel, QComboBox,
    QMessageBox, QDialog, QFormLayout, QLineEdit, QDialogButtonBox,
    QSplitter, QListWidget, QListWidgetItem, QInputDialog, QColorDialog,
    QPlainTextEdit, QSystemTrayIcon, QMenu, QStyle, QGraphicsOpacityEffect
)
from PySide6.QtGui import QColor, QPalette, QPixmap, QPainter, QBrush

from alice.config import load_config, save_config, APP_DIR, DEFAULT_CONFIG
from alice.database import Database
from alice.memory import MemoryManager
from alice.providers import AIWorker, test_provider_connection

PROJECT_DIR = Path(__file__).resolve().parent

def resource_path(relative: str) -> Path:
    """Путь к ресурсам как из исходников, так и из PyInstaller one-file."""
    base = Path(getattr(sys, "_MEIPASS", PROJECT_DIR))
    return base / relative


def make_stylesheet(accent: str = "#B8C0CC") -> str:
    """Единая тёмная полупрозрачная тема ALICE AI."""
    color = QColor(accent)
    if not color.isValid():
        color = QColor("#B8C0CC")
    accent = color.name()
    accent_border = f"rgba({color.red()}, {color.green()}, {color.blue()}, 0.38)"
    return f"""
        QMainWindow, QDialog {{ background: #090a0e; color: #f2f3f7; }}
        QWidget {{ color: #f2f3f7; font-size: 14px; }}
        QWidget#root {{ background: transparent; }}
        QLabel#title {{ font-size: 27px; font-weight: 700; color: #ffffff; }}
        QLabel#muted {{ color: #9298a6; font-size: 12px; }}
        QLabel#section {{ color: #c4c8d2; font-size: 11px; font-weight: 700; letter-spacing: 1px; }}
        QTextBrowser, QTextEdit, QPlainTextEdit, QListWidget {{
            background: rgba(12,13,18,0.62); color: #f2f3f7;
            border: 1px solid {accent_border};
            border-radius: 18px; padding: 13px; selection-background-color: {accent};
        }}
        QTextBrowser {{ background: rgba(12,13,18,0.58); }}
        QTextEdit, QPlainTextEdit {{ selection-color: #ffffff; }}
        QListWidget {{ background: rgba(12,13,18,0.48); }}
        QPushButton {{
            background: rgba(10,11,16,0.58); color: #f5f5f8;
            border: 1px solid rgba(255,255,255,0.10);
            border-radius: 14px; padding: 10px 16px;
        }}
        QPushButton:hover {{ background: rgba(255,255,255,0.13); border-color: {accent}; }}
        QPushButton:pressed {{ background: {accent}; }}
        QPushButton:disabled {{ background: rgba(12,13,18,0.58); color: #686d78; }}
        QPushButton#accentButton {{ background: rgba(12,13,18,0.58); border: 1px solid {accent}; color: #f2f3f7; font-weight: 600; }}
        QPushButton#accentButton:hover {{ background: rgba(255,255,255,0.10); }}
        QLineEdit, QComboBox {{
            background: rgba(12,13,18,0.66); color: #f2f3f7;
            border: 1px solid {accent_border}; border-radius: 12px; padding: 9px 11px;
        }}
        QComboBox QAbstractItemView {{ background: #171920; color: #f2f3f7; selection-background-color: {accent}; }}
        QSplitter::handle {{ background: rgba(255,255,255,0.08); width: 5px; }}
        QScrollBar:vertical {{ background: transparent; width: 9px; margin: 4px; }}
        QScrollBar::handle:vertical {{ background: rgba(255,255,255,0.20); border-radius: 4px; min-height: 24px; }}
        QScrollBar::add-line:vertical, QScrollBar::sub-line:vertical {{ height: 0; }}
        QCheckBox {{ spacing: 8px; }}
    """


class SettingsDialog(QDialog):
    PROVIDERS = [
        ("Ollama — локальная модель", "ollama"),
        ("Groq", "groq"),
        ("OpenRouter (включая бесплатные модели)", "openrouter"),
        ("Mistral AI", "mistral"),
        ("Cloudflare Workers AI", "cloudflare"),
        ("Gemini API", "gemini"),
        ("OpenAI API", "openai"),
        ("Другой OpenAI-совместимый API", "openai_compatible"),
    ]
    DEFAULTS = {
        "groq": {"model": "llama-3.3-70b-versatile", "base_url": "https://api.groq.com/openai/v1"},
        "openrouter": {"model": "openrouter/free", "base_url": "https://openrouter.ai/api/v1"},
        "mistral": {"model": "mistral-small-latest", "base_url": "https://api.mistral.ai/v1"},
        "cloudflare": {"model": "@cf/meta/llama-3.1-8b-instruct", "base_url": ""},
        "gemini": {"model": "gemini-2.0-flash", "base_url": ""},
        "openai": {"model": "gpt-4o-mini", "base_url": "https://api.openai.com/v1"},
        "openai_compatible": {"model": "", "base_url": ""},
    }

    def __init__(self, config: dict, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Настройки ALICE AI")
        self.setMinimumWidth(570)
        self.config = dict(config)
        self.provider_settings = {k: dict(v) for k, v in (config.get("provider_settings", {}) or {}).items()}
        self.current_provider = config.get("provider", "ollama")
        # Перенос старых настроек v0.1 в профиль выбранного провайдера.
        self.provider_settings.setdefault(self.current_provider, {})
        legacy = self.provider_settings[self.current_provider]
        for key in ("api_key", "model", "base_url", "account_id"):
            if key not in legacy and config.get(key):
                legacy[key] = config[key]

        layout = QVBoxLayout(self)
        form = QFormLayout()
        self.provider = QComboBox()
        for label, value in self.PROVIDERS:
            self.provider.addItem(label, value)
        idx = self.provider.findData(self.current_provider)
        self.provider.setCurrentIndex(max(0, idx))

        self.model = QLineEdit()
        self.ollama_url = QLineEdit(config.get("ollama_url", "http://localhost:11434"))
        self.api_key = QLineEdit()
        self.api_key.setEchoMode(QLineEdit.EchoMode.Password)
        self.base_url = QLineEdit()
        self.account_id = QLineEdit()
        self.system_prompt = QTextEdit()
        self.system_prompt.setMaximumHeight(120)
        self.system_prompt.setPlainText(config.get("system_prompt", ""))
        self.temperature = QLineEdit(str(config.get("temperature", 0.7)))
        self.accent_color = config.get("accent_color", "#B8C0CC")
        self.color_button = QPushButton("Выбрать цвет")
        self._update_color_button()
        self.color_button.clicked.connect(self.choose_accent_color)

        form.addRow("Провайдер:", self.provider)
        self.model_label = QLabel("Модель:")
        form.addRow(self.model_label, self.model)
        self.ollama_url_label = QLabel("Адрес Ollama:")
        form.addRow(self.ollama_url_label, self.ollama_url)
        self.api_key_label = QLabel("API-ключ:")
        form.addRow(self.api_key_label, self.api_key)
        self.base_url_label = QLabel("Базовый URL API:")
        form.addRow(self.base_url_label, self.base_url)
        self.account_id_label = QLabel("Cloudflare Account ID:")
        form.addRow(self.account_id_label, self.account_id)
        form.addRow("Температура:", self.temperature)
        form.addRow("Цвет акцента:", self.color_button)
        form.addRow("Дополнительные системные инструкции:", self.system_prompt)
        layout.addLayout(form)

        self.note = QLabel()
        self.note.setWordWrap(True)
        self.note.setObjectName("muted")
        layout.addWidget(self.note)

        action_row = QHBoxLayout()
        self.test_button = QPushButton("Проверить подключение")
        self.test_button.clicked.connect(self.test_connection)
        action_row.addWidget(self.test_button)
        action_row.addStretch()
        layout.addLayout(action_row)

        buttons = QDialogButtonBox(QDialogButtonBox.StandardButton.Save | QDialogButtonBox.StandardButton.Cancel)
        buttons.accepted.connect(self.accept)
        buttons.rejected.connect(self.reject)
        layout.addWidget(buttons)

        self.provider.currentIndexChanged.connect(self._provider_changed)
        self._load_provider_fields(self.current_provider)
        self.setStyleSheet(make_stylesheet(self.accent_color))

    def _update_color_button(self):
        self.color_button.setText(self.accent_color.upper())
        self.color_button.setStyleSheet(
            f"QPushButton {{ background: rgba(255,255,255,0.04); color: #f2f3f7; "
            f"border: 1px solid {self.accent_color}; border-radius: 12px; padding: 9px; }}"
        )

    def choose_accent_color(self):
        chosen = QColorDialog.getColor(QColor(self.accent_color), self, "Цвет акцента")
        if chosen.isValid():
            self.accent_color = chosen.name()
            self._update_color_button()
            self.setStyleSheet(make_stylesheet(self.accent_color))

    def _save_visible_provider(self):
        provider = self.current_provider
        self.provider_settings[provider] = {
            "model": self.model.text().strip(),
            "api_key": self.api_key.text().strip(),
            "base_url": self.base_url.text().strip(),
            "account_id": self.account_id.text().strip(),
        }

    def _load_provider_fields(self, provider):
        settings = dict(self.provider_settings.get(provider, {}))
        defaults = self.DEFAULTS.get(provider, {})
        for key, value in defaults.items():
            settings.setdefault(key, value)
        if provider == "ollama":
            settings.setdefault("model", self.config.get("model", "qwen3:4b"))
        self.model.setText(settings.get("model", ""))
        self.api_key.setText(settings.get("api_key", ""))
        self.base_url.setText(settings.get("base_url", ""))
        self.account_id.setText(settings.get("account_id", ""))

        is_ollama = provider == "ollama"
        is_cloudflare = provider == "cloudflare"
        uses_key = provider != "ollama"
        uses_base = provider in {"groq", "openrouter", "mistral", "openai", "openai_compatible"}
        self.ollama_url.setVisible(is_ollama)
        self.ollama_url_label.setVisible(is_ollama)
        self.api_key.setVisible(uses_key)
        self.api_key_label.setVisible(uses_key)
        self.base_url.setVisible(uses_base)
        self.base_url_label.setVisible(uses_base)
        self.account_id.setVisible(is_cloudflare)
        self.account_id_label.setVisible(is_cloudflare)
        self.model_label.setText("Имя локальной модели:" if is_ollama else "ID модели:")

        notes = {
            "ollama": "Локальная модель. API-ключ и интернет не нужны. Установленные модели: qwen3:4b и qwen3.5:4b.",
            "groq": "Облачный API. Нужен ключ провайдера; бесплатный тариф имеет ограничения. Доступность моделей зависит от аккаунта.",
            "openrouter": "Агрегатор моделей. В качестве бесплатного варианта можно попробовать openrouter/free; бесплатные модели ограничены по запросам.",
            "mistral": "Облачный API Mistral. Условия бесплатного доступа и доступность API зависят от аккаунта и тарифа.",
            "cloudflare": "Нужны Cloudflare Account ID и API Token с доступом к Workers AI. Модель указывается в формате @cf/... .",
            "gemini": "Нужны API-ключ и точный ID модели Gemini. Доступность зависит от региона и условий аккаунта.",
            "openai": "OpenAI API требует отдельного API-баланса. Подписка ChatGPT не заменяет оплату API.",
            "openai_compatible": "Для совместимого API укажи его базовый URL, ID модели и ключ, если он требуется.",
        }
        self.note.setText(notes.get(provider, "Настройки провайдера."))
        self.test_button.setEnabled(True)

    def _provider_changed(self):
        self._save_visible_provider()
        self.current_provider = self.provider.currentData()
        self._load_provider_fields(self.current_provider)

    def _current_config(self):
        self._save_visible_provider()
        result = dict(self.config)
        result["provider"] = self.current_provider
        result["provider_settings"] = {k: dict(v) for k, v in self.provider_settings.items()}
        result["ollama_url"] = self.ollama_url.text().strip() or "http://localhost:11434"
        result["model"] = self.model.text().strip()
        result["api_key"] = self.api_key.text().strip()
        result["base_url"] = self.base_url.text().strip()
        result["account_id"] = self.account_id.text().strip()
        return result

    def test_connection(self):
        self.test_button.setEnabled(False)
        self.test_button.setText("Проверка…")
        QApplication.setOverrideCursor(Qt.CursorShape.WaitCursor)
        try:
            message = test_provider_connection(self._current_config())
            QMessageBox.information(self, "Проверка подключения", message)
        except Exception as exc:
            QMessageBox.warning(self, "Проверка подключения", str(exc))
        finally:
            QApplication.restoreOverrideCursor()
            self.test_button.setEnabled(True)
            self.test_button.setText("Проверить подключение")

    def get_config(self):
        try:
            temperature = max(0.0, min(2.0, float(self.temperature.text().replace(",", "."))))
        except ValueError:
            temperature = 0.7
        result = self._current_config()
        result["temperature"] = temperature
        result["accent_color"] = self.accent_color
        # Сохраняем совместимость с прежним форматом конфигурации.
        result["provider"] = self.current_provider
        return result


class PersonalityDialog(QDialog):
    """Редактор личности, чьи поля напрямую входят в системный промпт модели."""
    FIELDS = [
        ("description", "Описание личности", "Кто такая Алиса? Её роль, индивидуальность и особенности."),
        ("communication_style", "Стиль общения", "Тон, эмоциональность, длина и манера ответов."),
        ("behavior", "Поведение", "Как Алиса должна вести себя в диалоге и реагировать на разные ситуации."),
        ("rules", "Правила", "Что Алиса должна делать и чего избегать."),
        ("extra", "Дополнительные пожелания", "Любые дополнительные инструкции.")
    ]

    def __init__(self, config: dict, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Личность и интеллект Алисы")
        self.resize(720, 720)
        self.config = config
        self.editors = {}
        personality = config.get("personality", {}) or {}
        layout = QVBoxLayout(self)
        intro = QLabel("Эти настройки формируют системную инструкцию, которую Алиса получает при каждом новом запросе к модели.")
        intro.setWordWrap(True)
        intro.setObjectName("muted")
        layout.addWidget(intro)
        form = QFormLayout()
        for key, title, hint in self.FIELDS:
            editor = QPlainTextEdit()
            editor.setPlaceholderText(hint)
            editor.setPlainText(personality.get(key, ""))
            editor.setMinimumHeight(75 if key != "extra" else 90)
            self.editors[key] = editor
            form.addRow(title + ":", editor)
        layout.addLayout(form, 1)
        row = QHBoxLayout()
        reset = QPushButton("Вернуть стандартную личность")
        reset.clicked.connect(self.reset_defaults)
        row.addWidget(reset)
        row.addStretch()
        layout.addLayout(row)
        buttons = QDialogButtonBox(QDialogButtonBox.StandardButton.Save | QDialogButtonBox.StandardButton.Cancel)
        buttons.accepted.connect(self.accept)
        buttons.rejected.connect(self.reject)
        layout.addWidget(buttons)
        self.setStyleSheet(make_stylesheet(config.get("accent_color", "#B8C0CC")))

    def reset_defaults(self):
        defaults = DEFAULT_CONFIG.get("personality", {})
        for key, editor in self.editors.items():
            editor.setPlainText(defaults.get(key, ""))

    def get_personality(self):
        return {key: editor.toPlainText().strip() for key, editor in self.editors.items()}


class MarbleRoot(QWidget):
    """Чёрный мраморный фон; дочерние полупрозрачные панели показывают его сквозь себя."""
    def __init__(self, parent=None):
        super().__init__(parent)
        self.texture = QPixmap(str(resource_path("assets/black_marble.png")))

    def paintEvent(self, event):
        painter = QPainter(self)
        painter.setRenderHint(QPainter.RenderHint.SmoothPixmapTransform)
        painter.fillRect(self.rect(), QColor("#050609"))
        if not self.texture.isNull():
            scaled = self.texture.scaled(self.size(), Qt.AspectRatioMode.KeepAspectRatioByExpanding,
                                         Qt.TransformationMode.SmoothTransformation)
            x = (scaled.width() - self.width()) // 2
            y = (scaled.height() - self.height()) // 2
            painter.drawPixmap(0, 0, scaled, x, y, self.width(), self.height())
        painter.fillRect(self.rect(), QColor(0, 0, 0, 74))


class CompactWindow(QWidget):
    """Компактная плавающая панель: последние два сообщения и быстрый ввод."""
    def __init__(self, owner):
        super().__init__(None, Qt.WindowType.Tool | Qt.WindowType.FramelessWindowHint |
                         Qt.WindowType.WindowStaysOnTopHint)
        self.owner = owner
        self.setAttribute(Qt.WidgetAttribute.WA_TranslucentBackground, True)
        self.setWindowTitle("ALICE AI — компактный режим")
        self.setFixedWidth(430)
        # Компактное окно использует тот же акцент, который выбран в настройках.
        self.apply_accent(owner.config.get("accent_color", "#B8C0CC"))
        root = QVBoxLayout(self)
        root.setContentsMargins(12, 10, 12, 12)
        root.setSpacing(9)
        header = QHBoxLayout()
        name = QLabel("ALICE AI")
        name.setStyleSheet("font-size:15px;font-weight:700;letter-spacing:1px;")
        header.addWidget(name)
        header.addStretch()
        expand = QPushButton("Развернуть")
        expand.clicked.connect(owner.restore_main)
        header.addWidget(expand)
        hide = QPushButton("—")
        hide.setFixedWidth(38)
        hide.clicked.connect(self.hide)
        header.addWidget(hide)
        root.addLayout(header)
        self.recent = QLabel("Алиса готова к общению")
        self.recent.setObjectName("recent")
        self.recent.setWordWrap(True)
        self.recent.setMinimumHeight(54)
        self.recent.setMaximumHeight(145)
        root.addWidget(self.recent)
        self.opacity = QGraphicsOpacityEffect(self.recent)
        self.recent.setGraphicsEffect(self.opacity)
        self.fade = QPropertyAnimation(self.opacity, b"opacity", self)
        self.fade.setDuration(1800)
        self.fade.setStartValue(1.0)
        self.fade.setEndValue(0.0)
        self.fade.setEasingCurve(QEasingCurve.Type.OutCubic)
        self.expire = QTimer(self)
        self.expire.setSingleShot(True)
        self.expire.timeout.connect(self.fade.start)
        row = QHBoxLayout()
        self.entry = QLineEdit()
        self.entry.setPlaceholderText("Напиши Алисе…")
        self.entry.returnPressed.connect(self.send)
        row.addWidget(self.entry, 1)
        send = QPushButton("➤")
        send.setFixedWidth(46)
        send.clicked.connect(self.send)
        row.addWidget(send)
        root.addLayout(row)
        self.setObjectName("compactRoot")
        self.move_to_corner()

    def apply_accent(self, accent: str):
        color = QColor(accent)
        if not color.isValid():
            color = QColor("#B8C0CC")
        r, g, b = color.red(), color.green(), color.blue()
        self.setStyleSheet(f"""
            QWidget {{ color:#F7F8FC; font-size:14px; }}
            QWidget#compactRoot {{
                background:rgba(7,8,12,248);
                border:1px solid rgba({r},{g},{b},210);
                border-radius:22px;
            }}
            QLabel#recent {{
                background:rgba(25,27,36,248); color:#FFFFFF;
                border:1px solid rgba({r},{g},{b},105);
                border-radius:15px; padding:13px;
            }}
            QLineEdit {{
                background:rgba(24,26,34,250);
                border:1px solid rgba({r},{g},{b},190);
                border-radius:16px; padding:11px 13px; color:#FFFFFF;
            }}
            QLineEdit::placeholder {{ color:#B8BAC7; }}
            QPushButton {{
                background:rgba(28,30,40,248);
                border:1px solid rgba(190,190,210,100);
                border-radius:14px; padding:8px 12px; color:#FFFFFF;
            }}
            QPushButton:hover {{ border-color:rgb({r},{g},{b}); background:rgba(43,45,52,252); }}
        """)

    def move_to_corner(self):
        screen = QApplication.primaryScreen().availableGeometry()
        self.move(screen.right() - self.width() - 24, screen.bottom() - self.height() - 28)

    def send(self):
        text = self.entry.text().strip()
        if not text:
            return
        self.entry.clear()
        self.owner.submit_compact(text)
        self.entry.setPlaceholderText("Алиса отвечает…")

    def show_messages(self, messages):
        rows = []
        for role, content in messages[-2:]:
            who = "Ты" if role == "user" else "Алиса"
            safe = (content.replace("&", "&amp;").replace("<", "&lt;")
                    .replace(">", "&gt;").replace("\n", "<br>"))
            rows.append(f'<b>{who}</b><br>{safe}')
        self.recent.setText("<br><br>".join(rows) if rows else "Алиса готова к общению")
        self.opacity.setOpacity(1.0)
        self.fade.stop()
        self.expire.start(12000)
        self.adjustSize()
        self.setFixedWidth(430)
        self.move_to_corner()


class AliceWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("ALICE AI v0.6")
        self.resize(1120, 760)
        self.config = load_config()
        self.db = Database(APP_DIR / "alice_memory.sqlite3")
        self.memory = MemoryManager(self.db)
        self.worker = None
        self.pending_user_message = None

        central = MarbleRoot()
        central.setObjectName("root")
        self.setCentralWidget(central)
        main = QVBoxLayout(central)
        main.setContentsMargins(18, 16, 18, 16)
        main.setSpacing(12)

        top = QHBoxLayout()
        title = QLabel("ALICE AI")
        title.setObjectName("title")
        top.addWidget(title)
        subtitle = QLabel("Локальная ИИ-система с памятью · v0.6")
        subtitle.setObjectName("muted")
        top.addWidget(subtitle)
        top.addStretch()
        self.model_label = QLabel(self._model_status())
        self.model_label.setObjectName("muted")
        top.addWidget(self.model_label)
        personality_btn = QPushButton("Личность")
        personality_btn.clicked.connect(self.open_personality)
        top.addWidget(personality_btn)
        compact_btn = QPushButton("Компактный режим")
        compact_btn.clicked.connect(self.show_compact)
        top.addWidget(compact_btn)
        settings_btn = QPushButton("⚙ Настройки")
        settings_btn.clicked.connect(self.open_settings)
        top.addWidget(settings_btn)
        main.addLayout(top)

        splitter = QSplitter(Qt.Orientation.Horizontal)
        self.chat = QTextBrowser()
        self.chat.setOpenExternalLinks(True)
        self.chat.setObjectName("chat")
        splitter.addWidget(self.chat)

        side = QWidget()
        side_layout = QVBoxLayout(side)
        side_layout.setContentsMargins(10, 0, 0, 0)
        side_title = QLabel("ПАМЯТЬ АЛИСЫ")
        side_title.setObjectName("section")
        side_layout.addWidget(side_title)
        self.memory_list = QListWidget()
        side_layout.addWidget(self.memory_list, 1)
        memory_buttons = QHBoxLayout()
        add_memory = QPushButton("+ Запомнить")
        add_memory.clicked.connect(self.add_memory_dialog)
        delete_memory = QPushButton("Удалить")
        delete_memory.clicked.connect(self.delete_selected_memory)
        memory_buttons.addWidget(add_memory)
        memory_buttons.addWidget(delete_memory)
        side_layout.addLayout(memory_buttons)
        memory_note = QLabel("Воспоминания сохраняются локально и доступны разным моделям.")
        memory_note.setWordWrap(True)
        memory_note.setObjectName("muted")
        side_layout.addWidget(memory_note)
        splitter.addWidget(side)
        splitter.setSizes([790, 290])
        main.addWidget(splitter, 1)

        self.status = QLabel("Готова. История сохраняется автоматически.")
        self.status.setObjectName("muted")
        main.addWidget(self.status)

        input_row = QHBoxLayout()
        self.input = QTextEdit()
        self.input.setPlaceholderText("Напиши Алисе… (Enter — отправить, Shift+Enter — новая строка)")
        self.input.setFixedHeight(92)
        self.input.installEventFilter(self)
        input_row.addWidget(self.input, 1)
        self.send_button = QPushButton("Отправить")
        self.send_button.setMinimumWidth(125)
        self.send_button.setObjectName("accentButton")
        self.send_button.clicked.connect(self.send_message)
        input_row.addWidget(self.send_button)
        main.addLayout(input_row)

        self.setStyleSheet(make_stylesheet(self.config.get("accent_color", "#B8C0CC")))
        self.compact = CompactWindow(self)
        self.recent_messages = []
        self._setup_tray()

        self._load_history()
        self.refresh_memory()
        self._append_message("assistant", "Привет! Я Алиса. Это моя первая рабочая оболочка ALICE AI. Напиши мне сообщение.")
        self.chat.verticalScrollBar().setValue(self.chat.verticalScrollBar().maximum())

    def _setup_tray(self):
        self.tray = QSystemTrayIcon(self.style().standardIcon(QStyle.StandardPixmap.SP_ComputerIcon), self)
        self.tray.setToolTip("ALICE AI")
        menu = QMenu()
        show_action = menu.addAction("Открыть ALICE AI")
        show_action.triggered.connect(self.restore_main)
        compact_action = menu.addAction("Компактный режим")
        compact_action.triggered.connect(self.show_compact)
        menu.addSeparator()
        quit_action = menu.addAction("Выход")
        quit_action.triggered.connect(QApplication.quit)
        self.tray.setContextMenu(menu)
        self.tray.activated.connect(self._tray_activated)
        self.tray.show()

    def _tray_activated(self, reason):
        if reason == QSystemTrayIcon.ActivationReason.Trigger:
            self.restore_main()

    def show_compact(self):
        self.hide()
        self.compact.show()
        self.compact.raise_()
        self.compact.entry.setFocus()

    def restore_main(self):
        self.compact.hide()
        self.showNormal()
        self.raise_()
        self.activateWindow()

    def submit_compact(self, text):
        self.input.setPlainText(text)
        self.send_message()

    def _model_status(self):
        provider = self.config.get("provider", "ollama")
        names = {"ollama": "Ollama", "groq": "Groq", "openrouter": "OpenRouter", "mistral": "Mistral AI", "cloudflare": "Cloudflare", "gemini": "Gemini", "openai": "OpenAI", "openai_compatible": "OpenAI-compatible"}
        return f"{names.get(provider, provider)} · {self.config.get('model', '')}"

    def _append_message(self, role: str, content: str):
        self.recent_messages.append((role, content))
        self.recent_messages = self.recent_messages[-2:]
        if hasattr(self, "compact"):
            self.compact.show_messages(self.recent_messages)
        label = "Ты" if role == "user" else "Алиса"
        safe = (content.replace("&", "&amp;").replace("<", "&lt;")
                .replace(">", "&gt;").replace("\n", "<br>"))
        color = "#9fc4ff" if role == "user" else "#b7e3c0"
        self.chat.append(
            f'<p style="margin-top:12px;"><b style="color:{color}">{label}</b><br>{safe}</p>'
        )

    def _load_history(self):
        for item in self.db.get_all_messages():
            self._append_message(item["role"], item["content"])

    def refresh_memory(self):
        self.memory_list.clear()
        for item in self.memory.all():
            row = QListWidgetItem(item["content"])
            row.setData(Qt.ItemDataRole.UserRole, item["id"])
            row.setToolTip(item["content"])
            self.memory_list.addItem(row)

    def add_memory_dialog(self):
        value, ok = QInputDialog.getMultiLineText(
            self, "Новое воспоминание", "Что Алисе нужно запомнить?"
        )
        if ok and value.strip():
            self.memory.add(value.strip())
            self.refresh_memory()
            self.status.setText("Воспоминание сохранено в SQLite.")

    def delete_selected_memory(self):
        item = self.memory_list.currentItem()
        if item is None:
            return
        self.memory.delete(item.data(Qt.ItemDataRole.UserRole))
        self.refresh_memory()
        self.status.setText("Воспоминание удалено.")

    def open_personality(self):
        dialog = PersonalityDialog(self.config, self)
        if dialog.exec() == QDialog.DialogCode.Accepted:
            self.config["personality"] = dialog.get_personality()
            save_config(self.config)
            self.status.setText("Личность Алисы сохранена и будет применяться к следующим запросам.")

    def open_settings(self):
        dialog = SettingsDialog(self.config, self)
        if dialog.exec() == QDialog.DialogCode.Accepted:
            self.config = dialog.get_config()
            save_config(self.config)
            self.setStyleSheet(make_stylesheet(self.config.get("accent_color", "#B8C0CC")))
            self.compact.apply_accent(self.config.get("accent_color", "#B8C0CC"))
            self.model_label.setText(self._model_status())
            self.status.setText("Настройки сохранены.")

    def send_message(self):
        if self.worker is not None and self.worker.isRunning():
            return
        text = self.input.toPlainText().strip()
        if not text:
            return
        if text.startswith("/remember "):
            self.memory.add(text[len("/remember "):].strip())
            self.refresh_memory()
            self.input.clear()
            self.status.setText("Сохранила это в долговременную память.")
            self._append_message("user", text)
            self._append_message("assistant", "Хорошо, сохранила это в памяти.")
            self.db.add_message("user", text)
            self.db.add_message("assistant", "Хорошо, сохранила это в памяти.")
            self.compact.entry.setPlaceholderText("Напиши Алисе…")
            return
        if text == "/memories":
            memories = self.memory.all()
            answer = "\n".join(f"• {m['content']}" for m in memories) or "Память пока пуста."
            self._append_message("user", text)
            self._append_message("assistant", answer)
            self.db.add_message("user", text)
            self.db.add_message("assistant", answer)
            self.input.clear()
            self.compact.entry.setPlaceholderText("Напиши Алисе…")
            return

        self.input.clear()
        self.pending_user_message = text
        self._append_message("user", text)
        self.db.add_message("user", text)
        self.send_button.setEnabled(False)
        self.status.setText("Алиса думает…")
        self.worker = AIWorker(
            self.config,
            self.db.get_recent_messages(limit=30),
            self.memory.all()
        )
        self.worker.finished_text.connect(self.on_answer)
        self.worker.failed.connect(self.on_error)
        self.worker.finished.connect(self.on_worker_finished)
        self.worker.start()

    def on_answer(self, answer: str):
        self._append_message("assistant", answer)
        self.compact.entry.setPlaceholderText("Напиши Алисе…")
        self.db.add_message("assistant", answer)
        self.status.setText("Ответ получен. История сохранена.")

    def on_error(self, message: str):
        self._append_message("assistant", "Не удалось получить ответ:\n" + message)
        self.compact.entry.setPlaceholderText("Напиши Алисе…")
        self.status.setText("Возникла ошибка подключения или генерации.")

    def on_worker_finished(self):
        self.send_button.setEnabled(True)
        self.worker = None
        self.compact.entry.setPlaceholderText("Напиши Алисе…")
        self.input.setFocus()

    def eventFilter(self, obj, event):
        if obj is self.input and event.type() == QEvent.Type.KeyPress:
            if event.key() in (Qt.Key.Key_Return, Qt.Key.Key_Enter) and not (
                event.modifiers() & Qt.KeyboardModifier.ShiftModifier
            ):
                self.send_message()
                return True
        return super().eventFilter(obj, event)

    def closeEvent(self, event):
        # Крестик скрывает главное окно: приложение остаётся в системном трее.
        event.ignore()
        self.show_compact()

    def shutdown(self):
        if self.worker is not None and self.worker.isRunning():
            self.worker.wait(1500)
        self.db.close()

def main():
    app = QApplication(sys.argv)
    app.setApplicationName("ALICE AI")
    app.setStyle("Fusion")
    palette = QPalette()
    palette.setColor(QPalette.ColorRole.Window, QColor("#090a0e"))
    palette.setColor(QPalette.ColorRole.WindowText, QColor("#f2f3f7"))
    palette.setColor(QPalette.ColorRole.Base, QColor("#111319"))
    palette.setColor(QPalette.ColorRole.AlternateBase, QColor("#171a22"))
    palette.setColor(QPalette.ColorRole.Text, QColor("#f2f3f7"))
    palette.setColor(QPalette.ColorRole.Button, QColor("#171a22"))
    palette.setColor(QPalette.ColorRole.ButtonText, QColor("#f2f3f7"))
    palette.setColor(QPalette.ColorRole.Highlight, QColor("#B8C0CC"))
    palette.setColor(QPalette.ColorRole.HighlightedText, QColor("#ffffff"))
    palette.setColor(QPalette.ColorRole.PlaceholderText, QColor("#858b99"))
    app.setPalette(palette)
    window = AliceWindow()
    app.aboutToQuit.connect(window.shutdown)
    window.show()
    sys.exit(app.exec())

if __name__ == "__main__":
    main()
